using Microsoft.AspNetCore.Mvc;
using Movie_Chat.Models;
using Movie_Chat.Services;


namespace Movie_Chat.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class MoviesController : ControllerBase
{
    private readonly MovieRagService _rag;

    public MoviesController(MovieRagService rag)
    {
        _rag = rag;
    }

    [HttpPost("ask")]
    public async Task<IActionResult> Ask([FromBody] QuestionRequest req)
    {
        if (string.IsNullOrWhiteSpace(req?.Question))
            return BadRequest(new { error = "Question is required." });

        var answer = await _rag.AskAsync(req.Question);
        return Ok(new AskResponse { Answer = answer });
    }

    // Simple endpoint to return raw movie file (for frontend demo)
    [HttpGet("raw")]
    public IActionResult Raw()
    {
        var path = Path.Combine(AppContext.BaseDirectory, "Data", "movies.txt");
        if (!System.IO.File.Exists(path)) return NotFound();
        var text = System.IO.File.ReadAllText(path);
        return Ok(new { content = text });
    }
}
