﻿namespace Movie_Chat.Models
{
    public class MovieDocument
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Content { get; set; } // full text for RAG
    }

    public class Chunk
    {
        public string Id { get; set; }
        public string Text { get; set; }
        public Dictionary<string, object>? Metadata { get; set; }
    }

    public class QuestionRequest
    {
        public string Question { get; set; }
    }

    public class AskResponse
    {
        public string Answer { get; set; }
    }

   
}
