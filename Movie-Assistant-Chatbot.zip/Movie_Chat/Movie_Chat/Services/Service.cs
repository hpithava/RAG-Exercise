﻿using Movie_Chat.Models;
using System.Numerics;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Configuration;
using System.Net.Http.Headers;
using System.Text.RegularExpressions;
namespace Movie_Chat.Services
{
    public interface IEmbeddingService
    {
        Task AddDocumentsAsync(IEnumerable<Chunk> chunks);
        Task<IEnumerable<Chunk>> RetrieveAsync(string query, int k = 2);
    }



    public class InMemoryVectorStore : IEmbeddingService
    {
        private readonly List<(Chunk chunk, float[] vector)> _store = new();

        // NOTE: This is a placeholder embedding function (hash-based). Replace with real embeddings.
        private float[] FakeEmbed(string text)
        {
            // deterministic pseudo-embedding: compute bytes and map to small vector
            var bytes = Encoding.UTF8.GetBytes(text);
            var vec = new float[64];
            for (int i = 0; i < bytes.Length; i++)
            {
                vec[i % vec.Length] += bytes[i];
            }
            // normalize
            var norm = MathF.Sqrt(vec.Sum(v => v * v));
            if (norm > 0)
            {
                for (int i = 0; i < vec.Length; i++) vec[i] /= norm;
            }
            return vec;
        }

        public Task AddDocumentsAsync(IEnumerable<Chunk> chunks)
        {
            foreach (var c in chunks)
            {
                var v = FakeEmbed(c.Text);
                _store.Add((c, v));
            }
            return Task.CompletedTask;
        }

        public Task<IEnumerable<Chunk>> RetrieveAsync(string query, int k = 2)
        {
            var qv = FakeEmbed(query);
            var scored = _store
                .Select(x => new { x.chunk, score = Dot(x.vector, qv) })
                .OrderByDescending(x => x.score)
                .Take(k)
                .Select(x => x.chunk);
            return Task.FromResult(scored);
        }

        private static float Dot(float[] a, float[] b)
        {
            float s = 0;
            for (int i = 0; i < a.Length && i < b.Length; i++) s += a[i] * b[i];
            return s;
        }
    }




    public class GeminiService
    {
        private readonly HttpClient _http;
        private readonly string _apiKey;
        private readonly string _model;
        private readonly string _baseUrl;

        public GeminiService(IConfiguration config)
        {
            _http = new HttpClient();
            _apiKey = Environment.GetEnvironmentVariable("GOOGLE_API_KEY") ?? config["GOOGLE_API_KEY"];
            _model = config["Gemini:Model"] ?? "gemini-3.1-flash-lite";
            _baseUrl = config["Gemini:ApiUrl"] ?? "https://generativelanguage.googleapis.com/v1beta/models";
        }

        public static string ExtractText(string jsonResponse)
        {
            try
            {
                using var doc = JsonDocument.Parse(jsonResponse);
                var root = doc.RootElement;

                // Navigate into candidates[0].content.parts[0].text
                if (root.TryGetProperty("candidates", out var candidates) && candidates.GetArrayLength() > 0)
                {
                    var firstCandidate = candidates[0];

                    if (firstCandidate.TryGetProperty("content", out var content))
                    {
                        if (content.TryGetProperty("parts", out var parts) && parts.ValueKind == JsonValueKind.Array)
                        {
                            var texts = new List<string>();
                            foreach (var part in parts.EnumerateArray())
                            {
                                if (part.TryGetProperty("text", out var textProp) && textProp.ValueKind == JsonValueKind.String)
                                {
                                    texts.Add(textProp.GetString());
                                }
                                else
                                {
                                    texts.Add(part.ToString());
                                }
                            }
                            return string.Join("\n", texts);
                        }
                    }
                }

                // Fallback: return raw JSON if no text found
                return jsonResponse;
            }
            catch (Exception)
            {
                return jsonResponse;
            }
        }
        public async Task<string> AskAsync(string prompt)
        {
            if (string.IsNullOrEmpty(_apiKey))
                throw new InvalidOperationException("GOOGLE_API_KEY not set.");

            var url = $"{_baseUrl}/{_model}:generateContent?key={_apiKey}";

            var requestBody = new
            {
                contents = new[]
                {
            new {
                parts = new[]
                {
                    new { text = prompt }
                }
            }
            },
                generationConfig = new
                {
                    temperature = 0.0,
                    maxOutputTokens = 512
                }
            };

            var json = JsonSerializer.Serialize(requestBody);
            using var req = new HttpRequestMessage(HttpMethod.Post, url)
            {
                Content = new StringContent(json, Encoding.UTF8, "application/json")
            };

            Console.WriteLine("Request URL: " + url);
            Console.WriteLine("Request Body: " + json);

            var resp = await _http.SendAsync(req);
            var body = await resp.Content.ReadAsStringAsync();

            Console.WriteLine("Status: " + resp.StatusCode);
            Console.WriteLine("Response Body: " + body);

            return  ExtractText(body);

        }
    }






    public class MovieRagService
    {
        private readonly IEmbeddingService _vectorStore;
        private readonly GeminiService _gemini;

        private const int ChunkSize = 300;
        private const int ChunkOverlap = 40;

        public MovieRagService(IEmbeddingService vectorStore, GeminiService gemini)
        {
            _vectorStore = vectorStore;
            _gemini = gemini;

            // Load and index documents at startup
            Task.Run(async () => await LoadAndIndexAsync()).Wait();
        }

        private async Task LoadAndIndexAsync()
        {
            var path = Path.Combine(AppContext.BaseDirectory, "Data", "movies.txt");
            if (!File.Exists(path))
            {
                // no-op if missing
                return;
            }
            try
            {
                var text = await File.ReadAllTextAsync(path);
                var docs = SplitIntoChunks(text);
                await _vectorStore.AddDocumentsAsync(docs);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error loading and indexing documents: " + ex.Message);
            }
        }

        private IEnumerable<Chunk> SplitIntoChunks(string text)
        {
            var chunks = new List<Chunk>();
            for (int i = 0; i < text.Length; i += ChunkSize - ChunkOverlap)
            {
                var length = Math.Min(ChunkSize, text.Length - i);
                chunks.Add(new Chunk { Id = Guid.NewGuid().ToString(), Text = text.Substring(i, length) });
            }
            return chunks;
            return chunks;
        }

        private string BuildPrompt(IEnumerable<Chunk> chunks, string question)
        {
            var context = string.Join("\n\n", chunks.Select(c => c.Text));
            var prompt = $@"Answer the question using ONLY the context provided below.
            If the answer cannot be found in the context, reply strictly with:
            ""I don't have this information in the document.""
            Do not guess, do not use external knowledge, and do not make anything up.

            Context:
            {context}

            Question: {question}

            Answer:";
            return prompt;
        }

        public async Task<string> AskAsync(string question)
        {
            var top = await _vectorStore.RetrieveAsync(question, k: 2);
            var prompt = BuildPrompt(top, question);
            var response = await _gemini.AskAsync(prompt);
            return response;
        }
    }



}
