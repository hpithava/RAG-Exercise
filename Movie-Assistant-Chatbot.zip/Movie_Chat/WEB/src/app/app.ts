import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

interface Message {
  sender: 'user' | 'bot';
  text: string;
}
@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  standalone: false,
  styleUrl: './app.css'
})
export class App {
   title = 'MovieRAG Chat';
  query = '';
  messages: Message[] = [];
  loading = false;

  constructor(private http: HttpClient) {}

  ask() {
    if (!this.query.trim()) return;

    // Add user message
    this.messages.push({ sender: 'user', text: this.query });

    this.loading = true;

    this.http.post<any>('http://localhost:5134/api/Movies/ask', { question: this.query })
      .subscribe({
        next: (res) => {
          this.messages.push({ sender: 'bot', text: res.answer|| 'No response' });
          this.loading = false;
        },
        error: (err) => {
          this.messages.push({ sender: 'bot', text: 'Error: ' + (err?.message || 'unknown') });
          this.loading = false;
        }
      });

    this.query = '';
  }
}
